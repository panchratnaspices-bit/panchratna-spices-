import React from 'react';
import { BRAND_STORY } from '../data/aboutData';
import { Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

export const ManufacturingProcess: React.FC = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto bg-black/5 dark:bg-[#120A07] rounded-3xl border border-[#D4AF37]/30 my-12">
      <div className="text-center space-y-4 mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 dark:bg-[#8B0000]/30 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5" /> From Farm to Kitchen
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Our Cold Grinding <span className="text-gold-gradient">Process</span>
        </h2>
        <p className="max-w-2xl mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          A seamless blend of ancient stone-milling wisdom and state-of-the-art hygienic stainless-steel vacuum processing.
        </p>
      </div>

      {/* 4 Step Process Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
        {BRAND_STORY.processSteps.map((stepItem, idx) => (
          <div
            key={idx}
            className="relative p-6 rounded-2xl glass-gold-card border border-[#D4AF37]/40 space-y-4 hover:scale-105 transition-all shadow-xl group"
          >
            {/* Step Number Badge */}
            <div className="flex items-center justify-between">
              <span className="w-10 h-10 rounded-full bg-gradient-to-r from-[#8B0000] to-[#660000] text-[#D4AF37] text-sm font-extrabold font-serif-luxury flex items-center justify-center border border-[#D4AF37]/50 shadow-md">
                {stepItem.step}
              </span>
              <ShieldCheck className="w-5 h-5 text-[#D4AF37] opacity-60 group-hover:opacity-100 transition-opacity" />
            </div>

            <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
              {stepItem.title}
            </h3>

            <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
              {stepItem.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Quality Certification Badges Footer */}
      <div className="mt-12 p-6 rounded-2xl bg-black/10 dark:bg-black/40 border border-[#D4AF37]/20 flex flex-wrap items-center justify-around gap-4 text-center">
        {BRAND_STORY.certifications.map((cert, i) => (
          <div key={i} className="space-y-0.5">
            <span className="text-xs font-bold text-[#D4AF37] block font-serif-luxury uppercase">
              {cert.name}
            </span>
            <span className="text-[11px] text-[#5C4A42] dark:text-[#C0B1A5] block">
              {cert.code}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
};
