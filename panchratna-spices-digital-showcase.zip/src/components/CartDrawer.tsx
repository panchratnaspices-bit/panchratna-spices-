import React from 'react';
import { Product } from '../types';
import { X, Trash2, ShoppingBag, MessageCircle, ArrowRight } from 'lucide-react';

export interface CartItem {
  id: string; // product.id + weight
  product: Product;
  selectedWeight: string;
  price: number;
  qty: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (id: string, newQty: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
}) => {
  if (!isOpen) return null;

  const grandTotal = cartItems.reduce((acc, item) => acc + item.price * item.qty, 0);

  const handleConsolidatedWhatsAppOrder = () => {
    let orderText = `Hello Panchratna Spices! I would like to place an order for the following items:\n\n`;
    cartItems.forEach((item, i) => {
      orderText += `${i + 1}. *${item.product.name}* (${item.selectedWeight}) - Qty: ${item.qty} - ₹${item.price * item.qty}\n`;
    });
    orderText += `\n*Grand Total:* ₹${grandTotal}\n\nPlease share payment details (UPI/Bank) and confirm dispatch to my address.`;

    const url = `https://wa.me/919823045678?text=${encodeURIComponent(orderText)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md h-full bg-[#FAF6F0] dark:bg-[#1C110C] text-[#1F1511] dark:text-[#FAF5EF] border-l-2 border-[#D4AF37]/50 shadow-2xl flex flex-col justify-between">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-[#8B0000] via-[#A00000] to-[#500000] text-white flex items-center justify-between border-b border-[#D4AF37]/30">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="text-lg font-bold font-serif-luxury">Order Basket</h3>
            <span className="text-xs bg-[#D4AF37] text-[#120A07] px-2 py-0.5 rounded-full font-bold">
              {cartItems.length} items
            </span>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Item List */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          {cartItems.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <ShoppingBag className="w-16 h-16 text-[#D4AF37] opacity-40 mx-auto" />
              <h4 className="text-base font-bold font-serif-luxury">Your Basket is Empty</h4>
              <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
                Explore our pure spices and click "Add to Basket" to compose your order.
              </p>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-white dark:bg-[#2A1A12] border border-[#E6DFD5] dark:border-[#38241B] flex items-center justify-between gap-3 shadow-sm"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-xl object-cover shrink-0"
                />

                <div className="flex-1 space-y-1">
                  <h4 className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF]">
                    {item.product.name}
                  </h4>
                  <p className="text-[11px] text-[#D4AF37] font-semibold">
                    Pack: {item.selectedWeight} • ₹{item.price} each
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => onUpdateQty(item.id, Math.max(1, item.qty - 1))}
                      className="w-5 h-5 rounded bg-[#8B0000] text-white text-xs font-bold flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className="text-xs font-bold w-4 text-center">{item.qty}</span>
                    <button
                      onClick={() => onUpdateQty(item.id, item.qty + 1)}
                      className="w-5 h-5 rounded bg-[#8B0000] text-white text-xs font-bold flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="text-right space-y-2">
                  <span className="text-sm font-extrabold text-[#8B0000] dark:text-[#D4AF37] block">
                    ₹{item.price * item.qty}
                  </span>
                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="text-red-500 hover:text-red-700 text-xs p-1"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Checkout */}
        {cartItems.length > 0 && (
          <div className="p-5 bg-black/5 dark:bg-[#120A07] border-t border-[#E6DFD5] dark:border-[#38241B] space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#5C4A42] dark:text-[#C0B1A5] font-semibold">Total Order Value:</span>
              <span className="text-xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
                ₹{grandTotal}
              </span>
            </div>

            <button
              onClick={handleConsolidatedWhatsAppOrder}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition-all hover:scale-105"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
              <span>Send Complete Order to WhatsApp</span>
            </button>

            <button
              onClick={onClearCart}
              className="w-full text-center text-xs text-[#5C4A42] dark:text-[#C0B1A5] hover:underline"
            >
              Clear Order Basket
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
