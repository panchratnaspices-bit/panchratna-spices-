import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, MessageCircle, Building, CheckCircle2, Sparkles } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    inquiryType: 'Retail Purchase',
    city: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        phone: '',
        email: '',
        inquiryType: 'Retail Purchase',
        city: '',
        message: ''
      });
    }, 4000);
  };

  const handleDirectWhatsAppForm = () => {
    const text = `Hello Panchratna Spices!\n\n*Inquiry Type:* ${formData.inquiryType}\n*Name:* ${formData.name || 'Customer'}\n*City:* ${formData.city || 'India'}\n*Phone:* ${formData.phone}\n*Message:* ${formData.message || 'I would like to inquire about Panchratna Spices.'}`;
    const url = `https://wa.me/919823045678?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-4 mb-16">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Building className="w-3.5 h-3.5" /> Get In Touch
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Contact <span className="text-gold-gradient">Panchratna Spices</span>
        </h2>
        <p className="max-w-xl mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          Whether you need pure spices for your home kitchen, bulk supply for your hotel/restaurant, or dealership opportunities, we are here for you.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        {/* Left Column: Direct Contact Info & Map Placeholder */}
        <div className="space-y-8">
          <div className="p-8 rounded-3xl glass-panel border border-[#D4AF37]/40 space-y-6 shadow-xl">
            <h3 className="text-2xl font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
              Factory & Administrative Office
            </h3>

            <div className="space-y-4 text-sm text-[#5C4A42] dark:text-[#C0B1A5]">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#1F1511] dark:text-[#FAF5EF]">Factory Address</h4>
                  <p className="mt-0.5 leading-relaxed">
                    Panchratna Spice Mills Private Limited,<br />
                    Plot No. 42, MIDC Food Park, Sangli-Kolhapur Highway,<br />
                    Sangli, Maharashtra - 416416, India
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#1F1511] dark:text-[#FAF5EF]">Customer Care & Orders Hotline</h4>
                  <p className="mt-0.5">+91 98230 45678 / +91 233 2671234</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#1F1511] dark:text-[#FAF5EF]">Official Email Address</h4>
                  <p className="mt-0.5">panchratnaspices@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 rounded-2xl bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-[#1F1511] dark:text-[#FAF5EF]">Operational Hours</h4>
                  <p className="mt-0.5">Monday to Saturday: 9:00 AM - 7:00 PM IST</p>
                </div>
              </div>
            </div>

            {/* Direct WhatsApp Callout */}
            <div className="p-4 rounded-2xl bg-emerald-600/10 border border-emerald-500/30 flex items-center justify-between gap-4">
              <div>
                <h5 className="text-xs font-bold text-emerald-500 uppercase tracking-wider">Fastest Response</h5>
                <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">Chat directly with our spice specialist team on WhatsApp.</p>
              </div>
              <a
                href="https://wa.me/919823045678?text=Hello%20Panchratna%20Spices!%20I%20have%20an%20inquiry."
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 shrink-0"
              >
                <MessageCircle className="w-4 h-4 fill-current" /> WhatsApp
              </a>
            </div>
          </div>

          {/* Interactive Google Maps Placeholder Frame */}
          <div className="rounded-3xl border-2 border-[#D4AF37]/40 overflow-hidden shadow-xl h-64 relative bg-[#120A07]">
            <iframe
              title="Panchratna Spices Google Maps Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d61081.77663243171!2d74.542289!3d16.852397!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc10c83a0000001%3A0x1000000000000000!2sMIDC%20Sangli%20Food%20Park!5e0!3m2!1sen!2sin!4v1650000000000!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen={false}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
            <div className="absolute bottom-3 left-3 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#D4AF37]/40 text-[11px] font-bold text-[#D4AF37] flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5" /> Panchratna Spice Mills, Sangli MIDC
            </div>
          </div>
        </div>

        {/* Right Column: Inquiry Form */}
        <div className="p-8 rounded-3xl glass-panel border-2 border-[#D4AF37]/50 shadow-2xl space-y-6">
          <div>
            <h3 className="text-2xl font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
              Send Us a Direct Message
            </h3>
            <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] mt-1">
              Fill out the form below or submit directly to WhatsApp for instant confirmation.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 rounded-2xl bg-emerald-600/10 border border-emerald-500/40 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h4 className="text-lg font-bold text-emerald-500">Inquiry Submitted Successfully!</h4>
              <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
                Thank you for reaching out to Panchratna Spices. Our executive will call or WhatsApp you within 2 business hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Inquiry Type Radio */}
              <div>
                <label className="text-xs font-bold uppercase text-[#D4AF37] block mb-2">Inquiry Category:</label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {['Retail Purchase', 'Restaurant / HORECA Bulk', 'Distributor / Dealership', 'Export Inquiry'].map((type) => (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setFormData({ ...formData, inquiryType: type })}
                      className={`py-2 px-3 rounded-xl border font-bold text-left transition-all ${
                        formData.inquiryType === type
                          ? 'bg-[#8B0000] text-white border-[#D4AF37]'
                          : 'bg-black/5 dark:bg-white/5 border-transparent text-[#1F1511] dark:text-[#C0B1A5]'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] block mb-1">Your Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ramesh Kulkarni"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] block mb-1">Mobile / WhatsApp Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+91 98230 00000"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Email & City */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] block mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@example.com"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] block mb-1">City / Location</label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Mumbai, Sangli, Pune"
                    className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] block mb-1">Your Requirements / Message</label>
                <textarea
                  rows={3}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Specify the spices required or dealership details..."
                  className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              {/* Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-[#8B0000] to-[#500000] text-white font-bold text-xs border border-[#D4AF37] shadow-lg flex items-center justify-center gap-2 hover:scale-105 transition-all"
                >
                  <Send className="w-4 h-4 text-[#D4AF37]" />
                  <span>Submit Inquiry</span>
                </button>

                <button
                  type="button"
                  onClick={handleDirectWhatsAppForm}
                  className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-all hover:scale-105"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Send via WhatsApp</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
