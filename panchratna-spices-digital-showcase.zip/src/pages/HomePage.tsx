import React, { useState } from 'react';
import { Hero } from '../components/Hero';
import { FeaturedProducts } from '../components/FeaturedProducts';
import { WhyChooseUs } from '../components/WhyChooseUs';
import { ManufacturingProcess } from '../components/ManufacturingProcess';
import { SpiceCalculator } from '../components/SpiceCalculator';
import { Reviews } from '../components/Reviews';
import { FaqSection } from '../components/FaqSection';
import { ContactSection } from '../components/ContactSection';
import { RecipeModal } from '../components/RecipeModal';
import { RECIPES } from '../data/recipesData';
import { Product, PageType, Recipe } from '../types';
import { Utensils, ArrowRight, Sparkles } from 'lucide-react';

interface HomePageProps {
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedWeight: string, price: number) => void;
  setActivePage: (page: PageType) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onQuickView,
  onAddToCart,
  setActivePage,
}) => {
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-12">
      {/* 1. Full Screen Hero */}
      <Hero
        setActivePage={setActivePage}
        onExploreClick={() => scrollToSection('featured-products-section')}
      />

      {/* 2. Featured Products */}
      <div id="featured-products-section">
        <FeaturedProducts
          onQuickView={onQuickView}
          onAddToCart={onAddToCart}
          setActivePage={setActivePage}
        />
      </div>

      {/* 3. Why Choose Us */}
      <WhyChooseUs />

      {/* 4. Manufacturing Process */}
      <ManufacturingProcess />

      {/* 5. Interactive Spice Ratio Assistant */}
      <SpiceCalculator />

      {/* 6. Recipe & Culinary Showcase */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
            <Utensils className="w-3.5 h-3.5" /> Culinary Recipes
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
            Authentic Indian <span className="text-gold-gradient">Spice Pairings</span>
          </h2>
          <p className="max-w-xl mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
            Discover step-by-step recipes specially crafted to highlight the natural flavor and aroma of Panchratna Spices.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {RECIPES.map((recipe) => (
            <div
              key={recipe.id}
              onClick={() => setSelectedRecipe(recipe)}
              className="group rounded-2xl bg-white dark:bg-[#1C110C] border border-[#E6DFD5] dark:border-[#38241B] hover:border-[#D4AF37] overflow-hidden shadow-md hover:shadow-2xl transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="relative h-52 overflow-hidden bg-[#120A07]">
                <img
                  src={recipe.image}
                  alt={recipe.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1C110C] via-transparent to-transparent opacity-80" />
                <span className="absolute bottom-3 left-3 px-3 py-1 rounded-full bg-[#8B0000] text-white text-[10px] font-bold uppercase tracking-wider">
                  {recipe.spiceUsed}
                </span>
              </div>

              <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF] group-hover:text-[#D4AF37] transition-colors">
                    {recipe.title}
                  </h3>
                  <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] line-clamp-2 mt-1">
                    {recipe.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#E6DFD5] dark:border-[#38241B] flex items-center justify-between text-xs font-bold text-[#8B0000] dark:text-[#D4AF37]">
                  <span>Prep: {recipe.prepTime} • Serves {recipe.servings}</span>
                  <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                    View Recipe <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedRecipe && (
          <RecipeModal
            recipe={selectedRecipe}
            onClose={() => setSelectedRecipe(null)}
          />
        )}
      </section>

      {/* 7. Reviews */}
      <Reviews />

      {/* 8. FAQ */}
      <FaqSection />

      {/* 9. Contact */}
      <ContactSection />
    </div>
  );
};
