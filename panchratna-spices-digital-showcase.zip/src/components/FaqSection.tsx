import React, { useState } from 'react';
import { FAQS } from '../data/faqData';
import { ChevronDown, Sparkles, Search, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('1');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Purity & Quality', 'Ordering & Shipping', 'Bulk Orders', 'General'];

  const filteredFaqs = FAQS.filter((faq) => {
    const matchesCat = activeCategory === 'All' || faq.category === activeCategory;
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      <div className="text-center space-y-4 mb-12">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <HelpCircle className="w-3.5 h-3.5" /> Frequently Asked Questions
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Everything You Need to <span className="text-gold-gradient">Know</span>
        </h2>
        <p className="max-w-lg mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          Have questions regarding cold grinding, curcumin levels, bulk orders, or WhatsApp delivery? Find answers here.
        </p>

        {/* Search Bar */}
        <div className="max-w-md mx-auto relative pt-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search questions (e.g., curcumin, bulk, expiry)..."
            className="w-full pl-10 pr-4 py-3 rounded-2xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-sm text-[#1F1511] dark:text-[#FAF5EF] placeholder-[#5C4A42] dark:placeholder-[#7C6A5E] focus:outline-none focus:border-[#D4AF37]"
          />
          <Search className="w-5 h-5 text-[#D4AF37] absolute left-3 top-5" />
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeCategory === cat
                  ? 'bg-[#8B0000] text-white border border-[#D4AF37]'
                  : 'bg-black/5 dark:bg-white/5 text-[#5C4A42] dark:text-[#C0B1A5] hover:bg-black/10 dark:hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Accordion List */}
      <div className="space-y-4">
        {filteredFaqs.length === 0 ? (
          <p className="text-center text-sm text-[#5C4A42] dark:text-[#C0B1A5] py-8">
            No matching questions found. Feel free to message us on WhatsApp!
          </p>
        ) : (
          filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="rounded-2xl glass-panel border border-[#D4AF37]/30 overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF] hover:text-[#8B0000] dark:hover:text-[#D4AF37] transition-colors"
                >
                  <span>{faq.question}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#D4AF37] shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 border-t border-[#E6DFD5]/50 dark:border-[#38241B]/50 text-xs sm:text-sm text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed animate-fadeIn">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};
