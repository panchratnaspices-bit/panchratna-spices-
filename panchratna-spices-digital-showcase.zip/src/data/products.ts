import { Product } from '../types';

export const PRODUCTS: Product[] = [
  {
    id: 'red-chilli-powder',
    name: 'Red Chilli Powder',
    hindiName: 'लाल मिर्च पाउडर',
    category: 'Pure Ground',
    shortDesc: 'Cold-milled stemless Guntur & Kashmiri chillies for rich crimson hue & balanced fiery warmth.',
    fullDesc: 'Panchratna Red Chilli Powder is crafted from handpicked sun-dried stemless chillies sourced directly from Guntur and Kashmir. Cold-milled at ambient low temperatures to lock in volatile essential oils, natural capsaicin, and rich crimson color without any artificial dyes or added pungency enhancers.',
    image: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 65 },
      { weight: '200g', price: 125 },
      { weight: '500g', price: 290 },
      { weight: '1kg', price: 560 }
    ],
    heatLevel: 4,
    aromaScore: 5,
    flavorNotes: ['Sun-dried Fruity', 'Warm Pungent', 'Natural Vibrant Crimson'],
    bestFor: ['Paneer Tikka', 'Chicken Curry', 'Dal Tadka', 'Sambar & Rasam'],
    ingredients: '100% Pure Sun-Dried Red Chilli Pods (Stemless)',
    origin: 'Guntur, Andhra Pradesh & Kashmir Valley',
    isBestseller: true
  },
  {
    id: 'turmeric-powder',
    name: 'Turmeric Powder',
    hindiName: 'हल्दी पाउडर',
    category: 'Pure Ground',
    shortDesc: 'High-curcumin (5%+) Salem fingers ground ultra-fine for brilliant golden color & immunity benefits.',
    fullDesc: 'Sourced from the golden fertile lands of Salem, Tamil Nadu, our Turmeric Powder contains high natural curcumin content (>5%). Naturally processed without lead chromate, polishing agents, or color fillers, ensuring immune-boosting wellness and traditional rich aroma in every pinch.',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 55 },
      { weight: '200g', price: 105 },
      { weight: '500g', price: 240 },
      { weight: '1kg', price: 460 }
    ],
    heatLevel: 1,
    aromaScore: 5,
    flavorNotes: ['Earthy Warm', 'Peppery Accent', 'Immunity Golden Glow'],
    bestFor: ['Golden Milk (Haldi Doodh)', 'Curries & Gravies', 'Kadha', 'Marinations'],
    ingredients: '100% Pure High-Curcumin Turmeric Rhizomes',
    curcuminContent: '5.2% Certified Active Curcumin',
    origin: 'Salem, Tamil Nadu',
    isBestseller: true
  },
  {
    id: 'coriander-powder',
    name: 'Coriander Powder',
    hindiName: 'धनिया पाउडर',
    category: 'Pure Ground',
    shortDesc: 'Slow-roasted green coriander seeds for fresh citrusy aroma & soothing cooling depth.',
    fullDesc: 'Made exclusively from premium Ramganj Mandi green coriander seeds. Lightly slow-roasted before stone cold-grinding, Panchratna Coriander Powder imparts a sweet citrusy aroma, thick body, and soothing herbal finish to all gravy dishes.',
    image: 'https://images.unsplash.com/photo-1599940824399-b87987ceb72a?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 50 },
      { weight: '200g', price: 95 },
      { weight: '500g', price: 220 },
      { weight: '1kg', price: 420 }
    ],
    heatLevel: 1,
    aromaScore: 4,
    flavorNotes: ['Citrus Woody', 'Sweet Herbal', 'Cooling Body'],
    bestFor: ['Chana Masala', 'Aloo Gobi', 'Stuffed Parathas', 'Veg Gravies'],
    ingredients: '100% Roasted Coriander Seeds (Dhania)',
    origin: 'Kota & Ramganj, Rajasthan',
    isBestseller: false
  },
  {
    id: 'garam-masala',
    name: 'Garam Masala',
    hindiName: 'शाही गरम मसाला',
    category: 'Specialty Blends',
    shortDesc: 'Royal artisanal blend of 18 handpicked whole spices, black cardamom, cloves & cinnamon.',
    fullDesc: 'A secret royal household recipe passed down through generations. Our Shahi Garam Masala combines 18 whole aromatic spices including black cardamom, green cardamom, star anise, nutmeg, mace, cloves, and Ceylon cinnamon, slow-roasted to perfection to unleash unmatched fragrance.',
    image: 'https://images.unsplash.com/photo-1509358217953-241c7b802e97?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 95 },
      { weight: '200g', price: 180 },
      { weight: '500g', price: 430 },
      { weight: '1kg', price: 820 }
    ],
    heatLevel: 3,
    aromaScore: 5,
    flavorNotes: ['Woody Sweet Spice', 'Cardamom Cloves Accent', 'Rich Mughlai Fragrance'],
    bestFor: ['Biryani', 'Shahi Paneer', 'Korma', 'Mutton Curry', 'Dal Makhani'],
    ingredients: 'Black Cardamom, Green Cardamom, Cinnamon, Cloves, Star Anise, Mace, Nutmeg, Cumin, Black Pepper, Bay Leaf, Fennel',
    origin: 'Kerala Spice Gardens & Royal Rajasthan',
    isBestseller: true
  },
  {
    id: 'kitchen-king-masala',
    name: 'Kitchen King Masala',
    hindiName: 'किचन किंग मसाला',
    category: 'Specialty Blends',
    shortDesc: 'The ultimate all-rounder curry spice master blend for restaurant-style Indian cooking.',
    fullDesc: 'Engineered as the multi-purpose culinary master blend, Panchratna Kitchen King brings together 22 balanced spices. Designed to effortlessly elevate simple everyday vegetable curries, cottage cheese dishes, and legumes into rich dhaba-style masterpieces.',
    image: 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 85 },
      { weight: '200g', price: 160 },
      { weight: '500g', price: 380 },
      { weight: '1kg', price: 730 }
    ],
    heatLevel: 2,
    aromaScore: 4,
    flavorNotes: ['Savory Umami', 'Balanced Warmth', 'Golden Gravy Enhancer'],
    bestFor: ['Mix Veg Fry', 'Matar Paneer', 'Kadai Mushroom', 'Aloo Dum'],
    ingredients: 'Coriander, Cumin, Turmeric, Black Pepper, Dry Ginger, Fenugreek Leaves (Kasoori Methi), Mustard, Onion Powder, Garlic Powder',
    origin: 'Multi-Region Supreme Blend',
    isBestseller: true
  },
  {
    id: 'kolhapuri-masala',
    name: 'Kolhapuri Masala',
    hindiName: 'कोल्हापुरी मसाला (कांदा लसूण)',
    category: 'Regional Masala',
    shortDesc: 'Authentic fiery Maharashtrian blend with dry roasted coconut, sesame & roasted red chillies.',
    fullDesc: 'Straight from the culinary heritage of Kolhapur, Maharashtra! Panchratna Kolhapuri Masala combines dark-roasted Byadgi and Lavangi chillies with slow-caramelized onions, garlic, toasted sesame seeds, and dry coconut (khobra) for that signature rich red tasset gravy and fiery punch.',
    image: 'https://images.unsplash.com/photo-1608897013039-887f21d8c804?auto=format&fit=crop&q=80&w=800',
    weights: [
      { weight: '100g', price: 90 },
      { weight: '200g', price: 170 },
      { weight: '500g', price: 400 },
      { weight: '1kg', price: 760 }
    ],
    heatLevel: 5,
    aromaScore: 5,
    flavorNotes: ['Roasted Coconut', 'Toasted Sesame', 'Smoky Fiery Red Gravy'],
    bestFor: ['Kolhapuri Chicken', 'Misal Pav', 'Veg Kolhapuri', 'Egg Curry', 'Shev Bhaji'],
    ingredients: 'Byadgi Chilli, Lavangi Chilli, Dry Coconut, Roasted Sesame, Garlic, Onion, Black Pepper, Poppy Seeds, Stone Flower (Dagad Phool)',
    origin: 'Kolhapur, Maharashtra',
    isBestseller: true,
    isNew: true
  }
];
