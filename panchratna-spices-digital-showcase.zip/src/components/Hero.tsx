import React from 'react';
import { PageType } from '../types';
import { Flame, Sparkles, MessageCircle, ArrowRight, ShieldCheck, Award, HeartPulse } from 'lucide-react';

interface HeroProps {
  setActivePage: (page: PageType) => void;
  onExploreClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ setActivePage, onExploreClick }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#120A07]">
      {/* Background Image Overlay with Dark Vignette */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_spices_1785416485459.jpg"
          alt="Panchratna Luxury Spices"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 scale-105 transition-transform duration-10000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#120A07] via-[#120A07]/75 to-[#120A07]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#120A07_90%)]" />
      </div>

      {/* Floating Gold Sparkle Accents */}
      <div className="absolute top-1/4 left-10 w-2 h-2 rounded-full bg-[#D4AF37] animate-ping opacity-75" />
      <div className="absolute bottom-1/3 right-12 w-3 h-3 rounded-full bg-[#D4AF37] animate-pulse opacity-60" />

      {/* Main Content */}
      <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
        {/* Top Tagline Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#2A1A12]/90 border border-[#D4AF37]/40 backdrop-blur-md shadow-2xl">
          <Sparkles className="w-4 h-4 text-[#D4AF37] animate-spin" />
          <span className="text-xs sm:text-sm font-semibold tracking-wider text-[#D4AF37] uppercase">
            AUTHENTIC INDIAN COLD-GROUND SPICES
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold font-serif-luxury text-[#FAF5EF] tracking-tight leading-[1.1]">
          The 5 Jewels of <br />
          <span className="text-gold-gradient drop-shadow-lg">Untainted Pure Taste</span>
        </h1>

        {/* Subtitle */}
        <p className="max-w-2xl mx-auto text-base sm:text-xl text-[#C0B1A5] font-normal leading-relaxed">
          Crafted from handpicked origin-specific crops and stone cold-milled at low temperatures to preserve 100% natural essential oils, vibrant color & rich heritage aroma.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={onExploreClick}
            id="hero-explore-btn"
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-[#8B0000] via-[#A00000] to-[#660000] text-[#FAF5EF] font-bold text-base border border-[#D4AF37] shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
          >
            <span>Explore Spice Range</span>
            <ArrowRight className="w-5 h-5 text-[#D4AF37]" />
          </button>

          <a
            href="https://wa.me/919823045678?text=Hello%20Panchratna%20Spices!%20I%20want%20to%20order%20spices%20directly."
            target="_blank"
            rel="noopener noreferrer"
            id="hero-whatsapp-btn"
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base border border-emerald-400/50 shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3"
          >
            <MessageCircle className="w-5 h-5 fill-current" />
            <span>Order on WhatsApp</span>
          </a>
        </div>

        {/* Feature Highlights Grid */}
        <div className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          {[
            {
              icon: Flame,
              title: 'Sub-Zero Cold Milled',
              desc: 'Preserves essential oils & natural aroma'
            },
            {
              icon: ShieldCheck,
              title: '100% Pure & Untainted',
              desc: 'No artificial color or lead chromate'
            },
            {
              icon: HeartPulse,
              title: 'High Active Curcumin',
              desc: '5.2%+ verified lab certified turmeric'
            },
            {
              icon: Award,
              title: 'Agmark Grade A',
              desc: 'FSSAI & ISO 22000 approved quality'
            }
          ].map((item, index) => {
            const IconComp = item.icon;
            return (
              <div
                key={index}
                className="p-4 rounded-2xl glass-panel border border-[#D4AF37]/20 hover:border-[#D4AF37]/60 transition-all group"
              >
                <div className="w-8 h-8 rounded-lg bg-[#8B0000]/20 text-[#D4AF37] flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                  <IconComp className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-[#FAF5EF] font-serif-luxury">{item.title}</h4>
                <p className="text-[11px] text-[#C0B1A5] mt-0.5 leading-snug">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
