import React, { useState } from 'react';
import { Review } from '../types';
import { Star, ShieldCheck, Quote, Sparkles, MessageCircle } from 'lucide-react';

export const REVIEWS_DATA: Review[] = [
  {
    id: '1',
    name: 'Chef Ranveer K.',
    location: 'Mumbai, Maharashtra',
    rating: 5,
    comment: 'Panchratna Red Chilli Powder has unmatched natural crimson color without artificial pungency dyes. In restaurant kitchens, cold-ground aroma makes a huge difference!',
    date: '14 July 2026',
    productBought: 'Red Chilli Powder & Garam Masala',
    verified: true
  },
  {
    id: '2',
    name: 'Sunita Deshmukh',
    location: 'Kolhapur, Maharashtra',
    rating: 5,
    comment: 'Authentic Kolhapuri Kanda Lasun Masala! The roasted coconut and garlic fragrance is exactly like home-ground traditional recipe. My Misal Pav now tastes heavenly.',
    date: '02 June 2026',
    productBought: 'Kolhapuri Masala (500g)',
    verified: true
  },
  {
    id: '3',
    name: 'Dr. Anita Roy',
    location: 'Bengaluru, Karnataka',
    rating: 5,
    comment: 'I tested their Turmeric Powder for curcumin content in my wellness store — over 5% active curcumin! Extremely pure and effective for golden milk kadha.',
    date: '28 May 2026',
    productBought: 'Turmeric Powder (1kg)',
    verified: true
  },
  {
    id: '4',
    name: 'Rajesh Sharma (Caterer)',
    location: 'Pune, Maharashtra',
    rating: 5,
    comment: 'We order 25kg bulk bags of Shahi Garam Masala and Kitchen King for wedding catering. Superb aroma stability and quick WhatsApp delivery support.',
    date: '10 April 2026',
    productBought: 'Shahi Garam Masala Bulk',
    verified: true
  }
];

export const Reviews: React.FC = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center space-y-4 mb-14">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5" /> Loved By 250,000+ Kitchens
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Customer <span className="text-gold-gradient">Reviews & Testimonials</span>
        </h2>
        <p className="max-w-xl mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          See why home cooks, professional chefs, caterers, and food lovers choose Panchratna Spices.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {REVIEWS_DATA.map((rev) => (
          <div
            key={rev.id}
            className="p-6 rounded-2xl glass-panel border border-[#D4AF37]/30 flex flex-col justify-between shadow-md hover:border-[#D4AF37] transition-all"
          >
            <div className="space-y-3">
              {/* Stars */}
              <div className="flex items-center gap-1 text-[#D4AF37]">
                {Array.from({ length: rev.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>

              <p className="text-xs sm:text-sm text-[#1F1511] dark:text-[#FAF5EF] italic leading-relaxed">
                "{rev.comment}"
              </p>
            </div>

            <div className="pt-4 mt-4 border-t border-[#E6DFD5] dark:border-[#38241B] space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold font-serif-luxury text-[#8B0000] dark:text-[#D4AF37]">
                  {rev.name}
                </span>
                {rev.verified && (
                  <span className="text-[10px] font-bold text-emerald-500 flex items-center gap-0.5">
                    <ShieldCheck className="w-3 h-3" /> Verified
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between text-[11px] text-[#5C4A42] dark:text-[#C0B1A5]">
                <span>{rev.location}</span>
                <span>{rev.date}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
