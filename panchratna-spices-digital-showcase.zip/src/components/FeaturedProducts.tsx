import React, { useState } from 'react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from './ProductCard';
import { Product, PageType } from '../types';
import { Sparkles, ArrowRight, Filter } from 'lucide-react';

interface FeaturedProductsProps {
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedWeight: string, price: number) => void;
  setActivePage: (page: PageType) => void;
}

export const FeaturedProducts: React.FC<FeaturedProductsProps> = ({
  onQuickView,
  onAddToCart,
  setActivePage,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Pure Ground', 'Specialty Blends', 'Regional Masala'];

  const filteredProducts = activeCategory === 'All'
    ? PRODUCTS
    : PRODUCTS.filter((p) => p.category === activeCategory);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center space-y-4 mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B0000]/10 dark:bg-[#8B0000]/30 border border-[#D4AF37]/30 text-[#8B0000] dark:text-[#D4AF37] text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5" /> Direct From Origin
        </div>
        <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Our Signature <span className="text-gold-gradient">Spice Collection</span>
        </h2>
        <p className="max-w-xl mx-auto text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          Handpicked crops, traditional formulas, and cold micro-milling. Discover the taste that elevates everyday curries into culinary royalty.
        </p>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-[#8B0000] to-[#660000] text-white border border-[#D4AF37] shadow-lg'
                  : 'bg-black/5 dark:bg-white/5 text-[#5C4A42] dark:text-[#C0B1A5] hover:bg-black/10 dark:hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onQuickView={onQuickView}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>

      {/* View All Products CTA Footer */}
      <div className="mt-12 text-center">
        <button
          onClick={() => {
            setActivePage('products');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-gradient-to-r from-[#8B0000] to-[#500000] text-[#FAF5EF] border border-[#D4AF37] font-bold text-sm shadow-xl hover:scale-105 transition-transform"
        >
          <span>Explore All 6 Products & Weights</span>
          <ArrowRight className="w-4 h-4 text-[#D4AF37]" />
        </button>
      </div>
    </section>
  );
};
