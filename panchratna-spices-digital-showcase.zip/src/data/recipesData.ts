import { Recipe } from '../types';

export const RECIPES: Recipe[] = [
  {
    id: 'shahi-paneer-tikka',
    title: 'Authentic Shahi Paneer Butter Masala',
    prepTime: '15 mins',
    cookTime: '25 mins',
    servings: '4 Persons',
    spiceUsed: 'Shahi Garam Masala & Red Chilli Powder',
    image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&q=80&w=800',
    description: 'Creamy restaurant-quality gravy infused with Panchratna Shahi Garam Masala and vibrant red chilli hue.',
    ingredients: [
      '300g Cottage Cheese (Paneer), cubed',
      '1 tsp Panchratna Red Chilli Powder',
      '1.5 tsp Panchratna Shahi Garam Masala',
      '1 tsp Panchratna Turmeric Powder',
      '2 tbsp Butter & 1 tbsp Oil',
      '3 Pureed Tomatoes & 1 Onion paste',
      '1/2 cup Cashew Paste & 2 tbsp Cream'
    ],
    instructions: [
      'Sauté onion paste in butter and oil until golden brown.',
      'Add tomato puree along with Panchratna Red Chilli Powder, Turmeric, and salt. Cook until oil separates.',
      'Stir in cashew paste and 1/2 cup warm water. Simmer for 5 minutes.',
      'Add fresh paneer cubes and finish with 1.5 tsp Panchratna Shahi Garam Masala and crushed kasoori methi.',
      'Serve piping hot with garlic butter naan or basmati rice.'
    ]
  },
  {
    id: 'kolhapuri-chicken-rassa',
    title: 'Fiery Kolhapuri Tambda Rassa',
    prepTime: '20 mins',
    cookTime: '35 mins',
    servings: '5 Persons',
    spiceUsed: 'Panchratna Kolhapuri Masala',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&q=80&w=800',
    description: 'The legendary Maharashtrian curry bursting with roasted coconut, garlic, and rich fiery red broth.',
    ingredients: [
      '500g Chicken / Mutton pieces',
      '3 tbsp Panchratna Kolhapuri Masala',
      '1 tsp Panchratna Turmeric Powder',
      '2 tbsp Ginger Garlic paste',
      '1 finely chopped Onion & 2 tbsp Oil',
      'Fresh Coriander leaves for garnish'
    ],
    instructions: [
      'Marinate chicken with Panchratna Turmeric Powder, salt, and 1 tbsp ginger-garlic paste for 15 mins.',
      'Heat oil in a heavy pot, sauté chopped onions till golden.',
      'Add chicken and cook in its natural juices for 10 minutes.',
      'Add 3 tbsp Panchratna Kolhapuri Masala and 3 cups boiling water to form the broth (Rassa).',
      'Cover and simmer for 20 minutes until tender. Serve hot with Bhakri or Rice.'
    ]
  },
  {
    id: 'golden-turmeric-immunity-latte',
    title: 'Royal Golden Turmeric Immunity Latte',
    prepTime: '5 mins',
    cookTime: '5 mins',
    servings: '2 Persons',
    spiceUsed: 'High-Curcumin Turmeric Powder',
    image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&q=80&w=800',
    description: 'Warm soothing elixir featuring 5.2% active curcumin Panchratna turmeric with cinnamon & honey.',
    ingredients: [
      '2 cups Almond Milk or Whole Dairy Milk',
      '1 tsp Panchratna Turmeric Powder',
      '1/4 tsp Freshly crushed Black Pepper',
      '1 pinch Cinnamon Powder',
      '1.5 tbsp Honey or Jaggery'
    ],
    instructions: [
      'Warm milk in a small saucepan over medium heat.',
      'Whisk in Panchratna Turmeric Powder, black pepper, and cinnamon powder.',
      'Simmer gently for 3-4 minutes without boiling over.',
      'Remove from heat, mix in honey, pour into mugs, and dust with cinnamon.'
    ]
  }
];
