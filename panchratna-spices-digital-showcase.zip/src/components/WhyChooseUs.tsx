import React from 'react';
import { ShieldCheck, ThermometerSnowflake, Tractor, Award, Sparkles, CheckCircle2 } from 'lucide-react';
import { BRAND_STORY } from '../data/aboutData';

export const WhyChooseUs: React.FC = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#E6DFD5] dark:border-[#38241B]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Column: Heading & Story */}
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" /> The Panchratna Difference
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF] leading-tight">
            Why Generations of Chefs & Families <span className="text-gold-gradient">Trust Us</span>
          </h2>

          <p className="text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
            Most commercial ground spices lose over 60% of their natural volatile essential oils during high-friction hot industrial grinding. Panchratna preserves nature’s gift through specialized cold-grinding and zero-adulteration quality controls.
          </p>

          <div className="space-y-3 pt-2">
            {[
              '100% Sun-Dried Origin Crops (Guntur, Salem, Ramganj & Kerala)',
              'Sub-Ambient Cold-Milling Locks Natural Volatile Essential Oils',
              'Zero Synthetic Dyes, Lead Chromate or Artificial Pungency Fillers',
              'Agmark Grade A & FSSAI Certified Hygienic Vacuum Foil Packaging'
            ].map((text, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <span className="text-xs sm:text-sm font-semibold text-[#1F1511] dark:text-[#FAF5EF]">
                  {text}
                </span>
              </div>
            ))}
          </div>

          {/* Stats Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6">
            {BRAND_STORY.stats.map((stat, idx) => (
              <div key={idx} className="p-3.5 rounded-2xl bg-black/5 dark:bg-white/5 border border-[#D4AF37]/30 text-center">
                <span className="block text-2xl font-extrabold font-serif-luxury text-[#8B0000] dark:text-[#D4AF37]">
                  {stat.value}
                </span>
                <span className="block text-[11px] font-semibold text-[#5C4A42] dark:text-[#C0B1A5] mt-1">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: 4 Pillar Feature Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {BRAND_STORY.coreValues.map((value, idx) => {
            const iconsMap: Record<string, React.ElementType> = {
              ShieldCheck,
              ThermometerSnowflake,
              Tractor,
              Award,
            };
            const IconComp = iconsMap[value.icon] || ShieldCheck;

            return (
              <div
                key={idx}
                className="p-6 rounded-2xl glass-panel border border-[#D4AF37]/30 hover:border-[#D4AF37] transition-all hover:-translate-y-1 group shadow-md"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8B0000] to-[#500000] border border-[#D4AF37] text-[#D4AF37] flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg">
                  <IconComp className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
                  {value.title}
                </h3>
                <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] mt-2 leading-relaxed">
                  {value.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
