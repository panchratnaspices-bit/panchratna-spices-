import React from 'react';
import { ContactSection } from '../components/ContactSection';
import { FaqSection } from '../components/FaqSection';
import { Sparkles, Building2, Truck, Handshake } from 'lucide-react';

export const ContactPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 space-y-12">
      {/* Banner */}
      <div className="px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5" /> Fast Response Team
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Contact & <span className="text-gold-gradient">Dealership Inquiries</span>
        </h1>
        <p className="text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          Connect directly with Panchratna Spice Mills for retail orders, restaurant bulk supplies, state-wide distributorships, and international exports.
        </p>
      </div>

      {/* 3 Channel Cards */}
      <div className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-3xl glass-panel border border-[#D4AF37]/30 space-y-2 text-center shadow-lg">
          <Building2 className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">Retail Orders</h3>
          <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">Direct doorstep vacuum sealed spice deliveries via WhatsApp.</p>
        </div>

        <div className="p-6 rounded-3xl glass-panel border border-[#D4AF37]/30 space-y-2 text-center shadow-lg">
          <Truck className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">HORECA Bulk Supply</h3>
          <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">5kg, 10kg, and 25kg commercial bags for hotels & caterers.</p>
        </div>

        <div className="p-6 rounded-3xl glass-panel border border-[#D4AF37]/30 space-y-2 text-center shadow-lg">
          <Handshake className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <h3 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">Distributor Partner</h3>
          <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">Join our expanding retail distribution network across India.</p>
        </div>
      </div>

      <ContactSection />
      <FaqSection />
    </div>
  );
};
