export const BRAND_STORY = {
  title: 'Panchratna Spices - The 5 Jewels of Pure Taste',
  subtitle: 'Preserving Centuries of Indian Culinary Heritage with Modern Cold-Grinding Hygiene',
  heroDesc: 'Founded with a singular passion to bring untainted, aromatic, and 100% natural spices to Indian households and global kitchens. "Panchratna" signifies the 5 precious jewels: Purity, Authenticity, Aroma, Freshness, and Health.',
  heritageText: 'For over three decades, Panchratna Spices has partnered directly with certified organic spice farmers across Guntur, Salem, Rajasthan, and Kerala. We eliminate middlemen to ensure fair remuneration for farmers and uncompromised spice quality for your family.',
  stats: [
    { label: 'Years of Trust', value: '30+' },
    { label: 'Pure Spice Varieties', value: '100%' },
    { label: 'Happy Kitchens Served', value: '250,000+' },
    { label: 'Quality Check Parameters', value: '42' }
  ],
  coreValues: [
    {
      icon: 'ShieldCheck',
      title: 'Zero Chemical Additives',
      description: 'Strictly no added colorants, lead chromate, starch fillers, or artificial pungency enhancers.'
    },
    {
      icon: 'ThermometerSnowflake',
      title: 'Cold-Grinding Technology',
      description: 'Milled at sub-ambient temperatures to preserve 100% of natural essential volatile oils.'
    },
    {
      icon: 'Tractor',
      title: 'Direct Farmer Sourcing',
      description: 'Sourced from GI-tagged regional hubs - Salem Turmeric, Guntur Chilli, Ramganj Coriander.'
    },
    {
      icon: 'Award',
      title: 'Lab Tested Certification',
      description: 'Every batch undergoes rigorous ISO, Agmark, and FSSAI pesticide residue & purity testing.'
    }
  ],
  certifications: [
    { name: 'FSSAI License', code: '11521034000128' },
    { name: 'Agmark Grade A', code: 'AGM/IND/2022' },
    { name: 'ISO 22000:2018', code: 'Certified FSMS' },
    { name: 'USFDA Registered', code: 'Export Standard' }
  ],
  processSteps: [
    {
      step: '01',
      title: 'Handpicked Origin Sourcing',
      desc: 'Selected directly at harvest peak from sun-blessed farms across India.'
    },
    {
      step: '02',
      title: 'Multi-Stage Sun Drying & Destoning',
      desc: 'Hygienic solar drying and triple air-jet destoning to remove all impurities.'
    },
    {
      step: '03',
      title: 'Stone-Cold Cryogenic Milling',
      desc: 'Low-heat micro-milling protects volatile essential oils and rich natural fragrance.'
    },
    {
      step: '04',
      title: 'Vacuum Sealed Luxury Packaging',
      desc: 'Aroma-lock foil pouches prevent oxidation and preserve farm-fresh flavor.'
    }
  ]
};
