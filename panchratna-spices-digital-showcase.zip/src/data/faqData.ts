import { FAQItem } from '../types';

export const FAQS: FAQItem[] = [
  {
    id: '1',
    question: 'How are Panchratna Spices different from commercial brand spices?',
    answer: 'Unlike high-speed industrial grinding that burns essential volatile oils due to extreme friction heat, Panchratna uses sub-zero cold-milling technology. We guarantee 100% pure spices without artificial colors, starch fillers, or lead chromate.',
    category: 'Purity & Quality'
  },
  {
    id: '2',
    question: 'What is the curcumin percentage in Panchratna Turmeric Powder?',
    answer: 'Our Turmeric Powder is sourced exclusively from Salem rhizomes and consistently tests at over 5.2% active Curcumin content (compared to the market average of 1.5% - 2%).',
    category: 'Purity & Quality'
  },
  {
    id: '3',
    question: 'How do I place an order via WhatsApp?',
    answer: 'Simply click any "Buy Now on WhatsApp" or "Inquire via WhatsApp" button on our website. It automatically composes your order details (Product, Weight, Quantity) into a WhatsApp message directly to our official sales team at +91 98230 45678.',
    category: 'Ordering & Shipping'
  },
  {
    id: '4',
    question: 'Do you offer bulk supplies for restaurants, caterers, or exports?',
    answer: 'Yes! We provide 5kg, 10kg, and 25kg commercial vacuum bags for hotels, restaurants, caterers (HORECA), and international distributors at special wholesale pricing. Please fill out our contact form or contact us directly on WhatsApp.',
    category: 'Bulk Orders'
  },
  {
    id: '5',
    question: 'What is the shelf life and storage recommendation?',
    answer: 'Panchratna Spices stay fresh and aromatic for 12 months from the date of manufacturing when stored in a cool, dry place inside an airtight glass or food-grade container away from direct sunlight.',
    category: 'General'
  },
  {
    id: '6',
    question: 'Is Kolhapuri Masala very spicy?',
    answer: 'Our Kolhapuri Kanda Lasun Masala has a fiery heat level (5/5) with authentic roasted coconut, garlic, and sesame flavors. You can adjust the quantity based on your spicy tolerance preference.',
    category: 'General'
  }
];
