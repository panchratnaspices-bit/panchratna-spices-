import React, { useState } from 'react';
import { Sparkles, Utensils, MessageCircle, Flame, ChefHat, Check } from 'lucide-react';
import { PRODUCTS } from '../data/products';

export const SpiceCalculator: React.FC = () => {
  const [dishType, setDishType] = useState<'curry' | 'biryani' | 'fry' | 'soup' | 'marination'>('curry');
  const [servings, setServings] = useState<number>(4);
  const [spiciness, setSpiciness] = useState<'mild' | 'medium' | 'fiery'>('medium');

  const getRecommendation = () => {
    switch (dishType) {
      case 'curry':
        return {
          title: 'Royal Indian Gravy Curry',
          spices: [
            { name: 'Red Chilli Powder', qty: spiciness === 'mild' ? '0.5 tsp' : spiciness === 'medium' ? '1.5 tsp' : '2.5 tsp' },
            { name: 'Turmeric Powder', qty: '0.75 tsp' },
            { name: 'Coriander Powder', qty: '2 tsp' },
            { name: 'Garam Masala', qty: '1 tsp (Finish at end)' }
          ],
          tip: 'Sauté coriander and turmeric in hot ghee first. Add Garam Masala in the last 2 minutes for maximum fragrance.'
        };
      case 'biryani':
        return {
          title: 'Dum Biryani & Mughlai Pulao',
          spices: [
            { name: 'Shahi Garam Masala', qty: spiciness === 'mild' ? '1.5 tsp' : '2.5 tsp' },
            { name: 'Red Chilli Powder', qty: spiciness === 'mild' ? '1 tsp' : '2 tsp' },
            { name: 'Turmeric Powder', qty: '0.5 tsp' }
          ],
          tip: 'Infuse Shahi Garam Masala in warm ghee before marinating mutton or chicken for 1 hour.'
        };
      case 'fry':
        return {
          title: 'Dry Veg & Paneer Stir Fry',
          spices: [
            { name: 'Kitchen King Masala', qty: '1.5 tsp' },
            { name: 'Coriander Powder', qty: '1 tsp' },
            { name: 'Red Chilli Powder', qty: spiciness === 'fiery' ? '1.5 tsp' : '0.75 tsp' }
          ],
          tip: 'Dust Kitchen King Masala directly over dry sautéed potatoes, cauliflower, or cottage cheese.'
        };
      case 'marination':
        return {
          title: 'Tandoori & Kolhapuri Special',
          spices: [
            { name: 'Kolhapuri Masala', qty: spiciness === 'mild' ? '1 tsp' : spiciness === 'medium' ? '2 tsp' : '3.5 tsp' },
            { name: 'Turmeric Powder', qty: '1 tsp' },
            { name: 'Red Chilli Powder', qty: '1 tsp' }
          ],
          tip: 'Mix Kolhapuri Masala with thick hung curd, ginger garlic paste, mustard oil, and lemon juice.'
        };
      case 'soup':
        return {
          title: 'Sambar, Rasam & Herbal Broth',
          spices: [
            { name: 'Turmeric Powder', qty: '1 tsp (High Curcumin)' },
            { name: 'Coriander Powder', qty: '1.5 tsp' },
            { name: 'Red Chilli Powder', qty: spiciness === 'fiery' ? '2 tsp' : '1 tsp' }
          ],
          tip: 'Boil high-curcumin turmeric powder with crushed black pepper for maximum bio-absorption and immune warmth.'
        };
    }
  };

  const rec = getRecommendation();

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
      <div className="p-8 sm:p-12 rounded-3xl glass-panel border-2 border-[#D4AF37]/50 shadow-2xl relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#8B0000]/20 rounded-full blur-3xl -z-10" />

        <div className="text-center space-y-3 mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
            <ChefHat className="w-4 h-4" /> Interactive Culinary Guide
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
            Panchratna <span className="text-gold-gradient">Spice Ratio Assistant</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#5C4A42] dark:text-[#C0B1A5]">
            Select your dish type and desired heat level to calculate the exact recommended spice combination for {servings} servings!
          </p>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Dish Type */}
          <div>
            <label className="text-xs font-bold uppercase text-[#D4AF37] block mb-2">1. Select Dish Type:</label>
            <div className="grid grid-cols-2 sm:grid-cols-1 gap-2">
              {[
                { id: 'curry', label: '🍲 Gravy Curry' },
                { id: 'biryani', label: '🍚 Biryani / Pulao' },
                { id: 'fry', label: '🥘 Veg Stir-Fry' },
                { id: 'marination', label: '🔥 Kolhapuri / Tandoor' },
                { id: 'soup', label: '🥣 Sambar & Rasam' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setDishType(item.id as any)}
                  className={`px-3 py-2.5 rounded-xl text-xs font-bold text-left transition-all border ${
                    dishType === item.id
                      ? 'bg-[#8B0000] text-white border-[#D4AF37] shadow-md'
                      : 'bg-black/5 dark:bg-white/5 border-transparent text-[#1F1511] dark:text-[#C0B1A5] hover:border-[#D4AF37]/40'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Servings Counter */}
          <div>
            <label className="text-xs font-bold uppercase text-[#D4AF37] block mb-2">2. Number of Servings:</label>
            <div className="p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-2xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">{servings} Servings</span>
                <span className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">Persons</span>
              </div>
              <input
                type="range"
                min={1}
                max={12}
                value={servings}
                onChange={(e) => setServings(Number(e.target.value))}
                className="w-full accent-[#8B0000]"
              />
              <p className="text-[11px] text-[#5C4A42] dark:text-[#C0B1A5] italic">
                Spice quantities dynamically scale proportionally for {servings} people.
              </p>
            </div>
          </div>

          {/* Heat Preference */}
          <div>
            <label className="text-xs font-bold uppercase text-[#D4AF37] block mb-2">3. Preferred Heat Level:</label>
            <div className="space-y-2">
              {[
                { id: 'mild', label: '🟢 Mild Warmth', desc: 'Family & kids friendly' },
                { id: 'medium', label: '🟡 Authentic Medium', desc: 'Balanced restaurant style' },
                { id: 'fiery', label: '🔴 Spicy Fiery', desc: 'True Kolhapuri & Guntur heat' }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSpiciness(item.id as any)}
                  className={`w-full p-3 rounded-xl text-left border transition-all ${
                    spiciness === item.id
                      ? 'bg-[#8B0000] text-white border-[#D4AF37] shadow-md'
                      : 'bg-black/5 dark:bg-white/5 border-transparent text-[#1F1511] dark:text-[#C0B1A5] hover:border-[#D4AF37]/40'
                  }`}
                >
                  <span className="text-xs font-bold block">{item.label}</span>
                  <span className="text-[10px] opacity-80 block">{item.desc}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Output Results Box */}
        <div className="p-6 rounded-2xl bg-gradient-to-br from-[#1C110C] to-[#2A1A12] border-2 border-[#D4AF37] text-white space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-[#D4AF37]/30 pb-3">
            <h3 className="text-lg font-bold font-serif-luxury text-[#D4AF37]">
              Recommended Recipe Blend: {rec.title}
            </h3>
            <span className="text-xs font-semibold px-2.5 py-1 rounded bg-[#8B0000] text-white">
              {servings} Portions
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {rec.spices.map((spice, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-black/40 border border-[#D4AF37]/20 flex items-center justify-between">
                <span className="text-xs font-bold text-[#FAF5EF] flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#D4AF37]" /> Panchratna {spice.name}
                </span>
                <span className="text-xs font-extrabold text-[#D4AF37] bg-[#8B0000]/40 px-2 py-0.5 rounded">
                  {spice.qty}
                </span>
              </div>
            ))}
          </div>

          <p className="text-xs text-[#C0B1A5] bg-black/20 p-3 rounded-xl border border-dashed border-[#D4AF37]/30 leading-relaxed">
            💡 <strong>Chef's Secret Tip:</strong> {rec.tip}
          </p>

          <div className="text-right pt-2">
            <a
              href={`https://wa.me/919823045678?text=Hello%20Panchratna%20Spices!%20I%20used%20your%20Spice%20Ratio%20Assistant%20for%20${encodeURIComponent(rec.title)}%20and%20need%20the%20spices.`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition-transform hover:scale-105"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Order These Spices on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
