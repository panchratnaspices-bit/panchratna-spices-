import React from 'react';
import { BRAND_STORY } from '../data/aboutData';
import { Sparkles, ShieldCheck, Award, ThermometerSnowflake, Tractor, CheckCircle2, Flame, HeartPulse } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16">
      {/* Header Banner */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-4 h-4" /> Three Decades of Heritage
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          The Panchratna <span className="text-gold-gradient">Legacy</span>
        </h1>
        <p className="text-base sm:text-lg text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
          {BRAND_STORY.subtitle}
        </p>
      </div>

      {/* Hero Image Section */}
      <div className="relative rounded-3xl overflow-hidden border-2 border-[#D4AF37]/40 shadow-2xl h-80 sm:h-96">
        <img
          src="/src/assets/images/spice_quality_1785416501845.jpg"
          alt="Panchratna Spice Manufacturing"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#120A07] via-black/40 to-transparent" />
        <div className="absolute bottom-6 left-6 right-6 max-w-2xl text-white space-y-2">
          <span className="px-3 py-1 rounded-full bg-[#D4AF37] text-[#120A07] text-xs font-bold uppercase">
            State-of-the-Art Quality
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold font-serif-luxury">
            Cold-Milled to Lock In 100% Volatile Essential Oils
          </h2>
        </div>
      </div>

      {/* Story & Philosophy */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h2 className="text-3xl font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
            The Meaning Behind <span className="text-gold-gradient">Panchratna</span>
          </h2>
          <p className="text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
            {BRAND_STORY.heroDesc}
          </p>
          <p className="text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
            {BRAND_STORY.heritageText}
          </p>

          <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {BRAND_STORY.stats.map((s, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-black/5 dark:bg-white/5 border border-[#D4AF37]/30 text-center">
                <span className="block text-2xl font-extrabold font-serif-luxury text-[#8B0000] dark:text-[#D4AF37]">
                  {s.value}
                </span>
                <span className="block text-[11px] font-semibold text-[#5C4A42] dark:text-[#C0B1A5] mt-1">
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Core Pillars */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider">
            Our 4 Uncompromising Standards
          </h3>
          <div className="space-y-4">
            {BRAND_STORY.coreValues.map((v, i) => (
              <div key={i} className="p-5 rounded-2xl glass-panel border border-[#D4AF37]/30 flex items-start gap-4">
                <div className="p-3 rounded-xl bg-[#8B0000] text-[#D4AF37] shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
                    {v.title}
                  </h4>
                  <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] mt-1 leading-relaxed">
                    {v.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Certifications Section */}
      <div className="p-8 rounded-3xl bg-black/5 dark:bg-[#1C110C] border-2 border-[#D4AF37]/40 text-center space-y-6">
        <h2 className="text-2xl sm:text-3xl font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Lab Tested & Certified For Your Family's Health
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
          {BRAND_STORY.certifications.map((c, idx) => (
            <div key={idx} className="p-4 rounded-2xl bg-white dark:bg-[#120A07] border border-[#D4AF37]/30 space-y-1">
              <Award className="w-8 h-8 text-[#D4AF37] mx-auto" />
              <span className="block text-sm font-bold text-[#1F1511] dark:text-[#FAF5EF] font-serif-luxury">
                {c.name}
              </span>
              <span className="block text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
                {c.code}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
