import React, { useState } from 'react';
import { MessageCircle, X, Send, Sparkles } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const text = message || 'Hello Panchratna Spices! I would like to inquire about your spices.';
    const url = `https://wa.me/919823045678?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    setIsOpen(false);
    setMessage('');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Quick Chat Popup Modal */}
      {isOpen && (
        <div className="mb-4 w-80 sm:w-88 rounded-2xl bg-[#1C110C] text-[#FAF5EF] border border-[#D4AF37]/40 shadow-2xl overflow-hidden animate-fadeIn">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#8B0000] via-[#A00000] to-[#500000] p-4 flex items-center justify-between border-b border-[#D4AF37]/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center text-white font-bold shadow-md">
                <MessageCircle className="w-5 h-5 fill-current" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#FAF5EF] font-serif-luxury">Panchratna Spices</h4>
                <p className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" /> Online | Instant Order
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-[#C0B1A5] hover:text-[#FAF5EF] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Chat Body */}
          <div className="p-4 space-y-3 text-xs bg-[#120A07]/90">
            <div className="p-3 rounded-xl bg-[#2A1A12] border border-[#38241B] text-[#FAF5EF] leading-relaxed">
              👋 Namaste! Welcome to Panchratna Spices. How can we assist you with your spice orders or dealership today?
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                '🌶️ Red Chilli Powder price?',
                '✨ Garam Masala bulk order',
                '🏬 Dealership Inquiry',
                '📦 Delivery timeline'
              ].map((quickText) => (
                <button
                  key={quickText}
                  onClick={() => setMessage(quickText)}
                  className="px-2.5 py-1 rounded-full bg-[#2A1A12] hover:bg-[#38241B] text-[#D4AF37] border border-[#D4AF37]/20 text-[11px] transition-colors"
                >
                  {quickText}
                </button>
              ))}
            </div>
          </div>

          {/* Input Form */}
          <form onSubmit={handleSend} className="p-3 bg-[#1C110C] border-t border-[#38241B] flex items-center gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 px-3 py-2 rounded-lg bg-[#120A07] border border-[#38241B] text-xs text-[#FAF5EF] placeholder-[#7C6A5E] focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              type="submit"
              className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors shadow-md flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Main Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        id="floating-whatsapp-btn"
        className="relative group p-4 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white shadow-2xl border-2 border-[#D4AF37] transition-all hover:scale-110 flex items-center justify-center"
        aria-label="Contact on WhatsApp"
      >
        <MessageCircle className="w-7 h-7 fill-current text-white" />
        <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-[#D4AF37]"></span>
        </span>
      </button>
    </div>
  );
};
