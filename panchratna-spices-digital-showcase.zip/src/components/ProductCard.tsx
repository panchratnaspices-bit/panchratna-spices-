import React, { useState } from 'react';
import { Product } from '../types';
import { Flame, ShoppingCart, MessageCircle, Eye, Sparkles, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedWeight: string, price: number) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onQuickView,
  onAddToCart,
}) => {
  const [selectedWeightIndex, setSelectedWeightIndex] = useState(0);
  const [added, setAdded] = useState(false);

  const currentWeightObj = product.weights[selectedWeightIndex];

  const handleWhatsAppBuy = (e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `Hello Panchratna Spices! I would like to order:\n\n*Product:* ${product.name} (${product.hindiName})\n*Weight:* ${currentWeightObj.weight}\n*Price:* ₹${currentWeightObj.price}\n\nPlease confirm availability and delivery address details.`;
    const url = `https://wa.me/919823045678?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleAddCartClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, currentWeightObj.weight, currentWeightObj.price);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div
      onClick={() => onQuickView(product)}
      className="group relative rounded-2xl bg-white dark:bg-[#1C110C] border border-[#E6DFD5] dark:border-[#38241B] hover:border-[#D4AF37] dark:hover:border-[#D4AF37] shadow-md hover:shadow-2xl transition-all duration-300 overflow-hidden flex flex-col cursor-pointer"
    >
      {/* Top Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1">
        {product.isBestseller && (
          <span className="px-2.5 py-1 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#B38F28] text-[#120A07] text-[10px] font-extrabold uppercase tracking-wider shadow-md flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> BESTSELLER
          </span>
        )}
        {product.isNew && (
          <span className="px-2.5 py-1 rounded-full bg-[#8B0000] text-[#FAF5EF] text-[10px] font-extrabold uppercase tracking-wider shadow-md">
            NEW LAUNCH
          </span>
        )}
      </div>

      {/* Heat Level Indicator Badge */}
      <div className="absolute top-3 right-3 z-10 px-2 py-1 rounded-full bg-black/60 backdrop-blur-md border border-[#D4AF37]/30 text-[#D4AF37] text-xs font-bold flex items-center gap-0.5">
        {Array.from({ length: product.heatLevel }).map((_, i) => (
          <span key={i} className="text-red-500">🌶️</span>
        ))}
      </div>

      {/* Product Image */}
      <div className="relative h-56 sm:h-64 w-full bg-[#120A07] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#1C110C] via-transparent to-transparent opacity-80" />

        {/* Quick View Hover Overlay Button */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="px-4 py-2 rounded-full bg-[#FAF5EF] text-[#120A07] font-bold text-xs flex items-center gap-2 shadow-xl hover:bg-[#D4AF37] transition-colors"
          >
            <Eye className="w-4 h-4" /> Quick Details
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-[#D4AF37] tracking-wider uppercase">
              {product.category}
            </span>
            <span className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] italic">
              {product.origin}
            </span>
          </div>

          <h3 className="text-lg font-bold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF] group-hover:text-[#8B0000] dark:group-hover:text-[#D4AF37] transition-colors mt-1">
            {product.name}
          </h3>
          <span className="text-xs font-semibold text-[#8B0000] dark:text-[#D4AF37] block">
            {product.hindiName}
          </span>

          <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] line-clamp-2 mt-2 leading-relaxed">
            {product.shortDesc}
          </p>
        </div>

        {/* Weights Selection Chips */}
        <div>
          <label className="text-[10px] font-semibold uppercase text-[#5C4A42] dark:text-[#C0B1A5] block mb-1.5">
            Select Pack Weight:
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {product.weights.map((w, idx) => (
              <button
                key={w.weight}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedWeightIndex(idx);
                }}
                className={`py-1 text-xs font-bold rounded-lg border transition-all ${
                  selectedWeightIndex === idx
                    ? 'bg-[#8B0000] text-white border-[#D4AF37] shadow-sm'
                    : 'bg-black/5 dark:bg-white/5 border-transparent text-[#1F1511] dark:text-[#C0B1A5] hover:border-[#D4AF37]/50'
                }`}
              >
                {w.weight}
              </button>
            ))}
          </div>
        </div>

        {/* Price & Action CTA */}
        <div className="pt-3 border-t border-[#E6DFD5] dark:border-[#38241B] flex items-center justify-between">
          <div>
            <span className="text-[10px] text-[#5C4A42] dark:text-[#C0B1A5] block">Price</span>
            <span className="text-xl font-extrabold text-[#1F1511] dark:text-[#FAF5EF] font-serif-luxury">
              ₹{currentWeightObj.price}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAddCartClick}
              className={`p-2.5 rounded-xl border transition-all ${
                added
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'border-[#D4AF37] text-[#1F1511] dark:text-[#FAF5EF] hover:bg-[#D4AF37]/10'
              }`}
              title="Add to Order Basket"
            >
              {added ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4 text-[#D4AF37]" />}
            </button>

            <button
              onClick={handleWhatsAppBuy}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all hover:scale-105"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Buy Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
