import React, { useState } from 'react';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';
import { Search, Filter, Sparkles, Flame, ShieldCheck } from 'lucide-react';

interface ProductsPageProps {
  onQuickView: (product: Product) => void;
  onAddToCart: (product: Product, selectedWeight: string, price: number) => void;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  onQuickView,
  onAddToCart,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedHeat, setSelectedHeat] = useState<number | 'All'>('All');

  const categories = ['All', 'Pure Ground', 'Specialty Blends', 'Regional Masala'];

  const filteredProducts = PRODUCTS.filter((p) => {
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.hindiName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.shortDesc.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesHeat = selectedHeat === 'All' || p.heatLevel === selectedHeat;

    return matchesCat && matchesSearch && matchesHeat;
  });

  return (
    <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      {/* Page Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#8B0000]/10 text-[#8B0000] dark:text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold uppercase tracking-widest">
          <Sparkles className="w-3.5 h-3.5" /> 100% Pure Origin Spices
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
          Complete <span className="text-gold-gradient">Spice Catalogue</span>
        </h1>
        <p className="text-sm sm:text-base text-[#5C4A42] dark:text-[#C0B1A5]">
          Explore our range of 100% cold-milled ground spices and artisanal regional masalas available in 100g, 200g, 500g, and 1kg vacuum sealed packs.
        </p>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="p-6 rounded-3xl glass-panel border border-[#D4AF37]/40 space-y-4 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          {/* Search Field */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search spices (e.g. Chilli, Turmeric, Kolhapuri)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
            />
            <Search className="w-4 h-4 text-[#D4AF37] absolute left-3 top-3" />
          </div>

          {/* Category Selector */}
          <div className="flex flex-wrap items-center gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#8B0000] text-white border border-[#D4AF37]'
                    : 'bg-black/5 dark:bg-white/5 text-[#5C4A42] dark:text-[#C0B1A5] hover:bg-black/10 dark:hover:bg-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Heat Level Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#D4AF37] whitespace-nowrap">Heat Level:</span>
            <select
              value={selectedHeat}
              onChange={(e) => setSelectedHeat(e.target.value === 'All' ? 'All' : Number(e.target.value))}
              className="px-3 py-2 rounded-xl bg-black/5 dark:bg-[#120A07] border border-[#E6DFD5] dark:border-[#38241B] text-xs text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none focus:border-[#D4AF37]"
            >
              <option value="All">All Heat Levels</option>
              <option value={1}>Mild (🌶️)</option>
              <option value={2}>Gentle Warmth (🌶️🌶️)</option>
              <option value={3}>Medium Hot (🌶️🌶️🌶️)</option>
              <option value={4}>Fiery Hot (🌶️🌶️🌶️🌶️)</option>
              <option value={5}>Kolhapuri Fiery (🌶️🌶️🌶️🌶️🌶️)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Product Cards */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-20 space-y-3">
          <Flame className="w-12 h-12 text-[#D4AF37] mx-auto opacity-40" />
          <h3 className="text-lg font-bold font-serif-luxury">No Spices Found</h3>
          <p className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
            Try clearing search filters or select a different category.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickView={onQuickView}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      )}
    </div>
  );
};
