import React from 'react';
import { Recipe } from '../types';
import { X, Clock, Users, Flame, Utensils } from 'lucide-react';

interface RecipeModalProps {
  recipe: Recipe | null;
  onClose: () => void;
}

export const RecipeModal: React.FC<RecipeModalProps> = ({ recipe, onClose }) => {
  if (!recipe) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#FAF6F0] dark:bg-[#1C110C] border-2 border-[#D4AF37]/50 text-[#1F1511] dark:text-[#FAF5EF] shadow-2xl overflow-hidden my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Hero Header Image */}
        <div className="relative h-60 w-full overflow-hidden bg-[#120A07]">
          <img
            src={recipe.image}
            alt={recipe.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1C110C] via-black/40 to-transparent" />
          <div className="absolute bottom-4 left-6 right-6">
            <span className="px-3 py-1 rounded-full bg-[#D4AF37] text-[#120A07] text-xs font-bold uppercase">
              Featured Recipe
            </span>
            <h2 className="text-2xl font-bold font-serif-luxury text-white mt-1">
              {recipe.title}
            </h2>
          </div>
        </div>

        {/* Recipe Info Chips */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-black/5 dark:bg-white/5 border border-[#E6DFD5] dark:border-[#38241B] text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-[#8B0000] dark:text-[#D4AF37]">
              <Clock className="w-4 h-4" /> Prep: {recipe.prepTime}
            </span>
            <span className="flex items-center gap-1.5 text-[#8B0000] dark:text-[#D4AF37]">
              <Utensils className="w-4 h-4" /> Cook: {recipe.cookTime}
            </span>
            <span className="flex items-center gap-1.5 text-[#8B0000] dark:text-[#D4AF37]">
              <Users className="w-4 h-4" /> Serves: {recipe.servings}
            </span>
          </div>

          {/* Key Spice Used */}
          <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-500 text-xs font-bold flex items-center gap-2">
            <Flame className="w-4 h-4" /> Recommended Panchratna Spice: {recipe.spiceUsed}
          </div>

          <p className="text-sm text-[#5C4A42] dark:text-[#C0B1A5]">
            {recipe.description}
          </p>

          {/* Ingredients */}
          <div>
            <h3 className="text-sm font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider mb-2">
              Ingredients
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
              {recipe.ingredients.map((ing, idx) => (
                <li key={idx} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />
                  <span>{ing}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Instructions */}
          <div>
            <h3 className="text-sm font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider mb-2">
              Step-by-Step Instructions
            </h3>
            <ol className="space-y-2 text-xs text-[#5C4A42] dark:text-[#C0B1A5]">
              {recipe.instructions.map((step, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#8B0000] text-white text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};
