import React from 'react';
import { PageType } from '../types';
import { Flame, MapPin, Phone, Mail, Clock, Shield, Award, Sparkles, Send } from 'lucide-react';

interface FooterProps {
  setActivePage: (page: PageType) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActivePage }) => {
  const [email, setEmail] = React.useState('');
  const [subscribed, setSubscribed] = React.useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 4000);
    }
  };

  return (
    <footer className="bg-[#120A07] text-[#FAF5EF] border-t-2 border-[#D4AF37]/40 pt-16 pb-12 relative overflow-hidden">
      {/* Decorative Gold Accent Bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#8B0000] via-[#D4AF37] to-[#8B0000]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8B0000] to-[#500000] border border-[#D4AF37] flex items-center justify-center">
                <Flame className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <div>
                <span className="block text-xl font-bold font-serif-luxury tracking-wider text-[#FAF5EF]">
                  PANCHRATNA
                </span>
                <span className="block text-[10px] font-semibold tracking-[0.2em] text-[#D4AF37] uppercase">
                  SPICES • 100% PURE
                </span>
              </div>
            </div>
            <p className="text-sm text-[#C0B1A5] leading-relaxed">
              Authentic Indian cold-ground spices crafted with traditional perfection. Bringing the 5 jewels of pure taste and rich aroma to every kitchen since 1994.
            </p>
            {/* Certifications Badges */}
            <div className="flex flex-wrap gap-2 pt-2">
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded bg-[#2A1A12] text-[#D4AF37] border border-[#D4AF37]/30">
                <Shield className="w-3 h-3" /> FSSAI Certified
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded bg-[#2A1A12] text-[#D4AF37] border border-[#D4AF37]/30">
                <Award className="w-3 h-3" /> Agmark Grade A
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-base font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider">
              Quick Navigation
            </h3>
            <ul className="space-y-2 text-sm text-[#C0B1A5]">
              <li>
                <button
                  onClick={() => {
                    setActivePage('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Home & Overview
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage('products');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Pure Ground Spices & Masalas
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Our Heritage & Cold Grinding Story
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActivePage('contact');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  Contact & Dealership Inquiries
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h3 className="text-base font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider">
              Factory & Support
            </h3>
            <ul className="space-y-3 text-sm text-[#C0B1A5]">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#D4AF37] mt-1 shrink-0" />
                <span>Panchratna Spice Mills, Plot 42, Food Park, Kolhapur Road, Sangli, Maharashtra - 416416</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>+91 98230 45678 / +91 233 2671234</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>panchratnaspices@gmail.com</span>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Mon - Sat: 9:00 AM - 7:00 PM</span>
              </li>
            </ul>
          </div>

          {/* Newsletter / Spice Tips */}
          <div className="space-y-4">
            <h3 className="text-base font-bold font-serif-luxury text-[#D4AF37] uppercase tracking-wider">
              Newsletter & Recipes
            </h3>
            <p className="text-sm text-[#C0B1A5]">
              Subscribe for authentic Indian spice recipes, kitchen tips, and special festive offers.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  required
                  className="w-full px-4 py-2.5 rounded-lg bg-[#1C110C] border border-[#38241B] text-sm text-[#FAF5EF] placeholder-[#7C6A5E] focus:outline-none focus:border-[#D4AF37]"
                />
                <button
                  type="submit"
                  className="absolute right-1 top-1 bottom-1 px-3 bg-[#D4AF37] hover:bg-[#B38F28] text-[#120A07] rounded-md font-bold transition-colors flex items-center justify-center"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              {subscribed && (
                <p className="text-xs text-[#D4AF37] flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Thank you for subscribing!
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 border-t border-[#38241B] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7C6A5E]">
          <p>© {new Date().getFullYear()} PANCHRATNA SPICES. All Rights Reserved. Crafted with purity.</p>
          <div className="flex items-center gap-6">
            <span>FSSAI Lic. No. 11521034000128</span>
            <span>Made in India 🇮🇳</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
