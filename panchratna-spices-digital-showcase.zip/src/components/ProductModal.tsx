import React, { useState } from 'react';
import { Product } from '../types';
import { X, MessageCircle, ShoppingBag, Flame, Sparkles, Check, ShieldCheck, HeartPulse } from 'lucide-react';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, selectedWeight: string, price: number, qty: number) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  const [selectedWeightIndex, setSelectedWeightIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const selectedWeightObj = product.weights[selectedWeightIndex];
  const totalPrice = selectedWeightObj.price * quantity;

  const handleWhatsAppOrder = () => {
    const text = `Hello Panchratna Spices! I would like to place an order:\n\n*Product:* ${product.name} (${product.hindiName})\n*Pack Size:* ${selectedWeightObj.weight}\n*Quantity:* ${quantity}\n*Total Price:* ₹${totalPrice}\n\n*Origin:* ${product.origin}\n*Delivery Address:* [Please enter your full address here]`;
    const url = `https://wa.me/919823045678?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleAddCart = () => {
    onAddToCart(product, selectedWeightObj.weight, selectedWeightObj.price, quantity);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl rounded-3xl bg-[#FAF6F0] dark:bg-[#1C110C] border-2 border-[#D4AF37]/50 text-[#1F1511] dark:text-[#FAF5EF] shadow-2xl overflow-hidden my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Product Image & Badges */}
          <div className="relative h-72 md:h-full bg-[#120A07] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#1C110C] via-transparent to-transparent opacity-80" />

            <div className="absolute bottom-4 left-4 right-4 space-y-2">
              <span className="inline-block px-3 py-1 rounded-full bg-[#8B0000] text-white text-xs font-bold uppercase tracking-wider">
                {product.category}
              </span>
              <h2 className="text-2xl font-bold font-serif-luxury text-white">
                {product.name}
              </h2>
              <p className="text-sm text-[#D4AF37] font-semibold">{product.hindiName}</p>
            </div>
          </div>

          {/* Right: Details & Buying Form */}
          <div className="p-6 md:p-8 space-y-6 flex flex-col justify-between max-h-[80vh] overflow-y-auto">
            <div className="space-y-4">
              {/* Heat & Curcumin info */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs border-b border-[#E6DFD5] dark:border-[#38241B] pb-3">
                <div className="flex items-center gap-1 text-[#D4AF37]">
                  <span className="font-bold">Heat Level:</span>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className={i < product.heatLevel ? 'text-red-500' : 'text-gray-600'}>🌶️</span>
                  ))}
                </div>
                {product.curcuminContent && (
                  <span className="px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-500 border border-amber-500/30 font-bold flex items-center gap-1">
                    <HeartPulse className="w-3.5 h-3.5" /> {product.curcuminContent}
                  </span>
                )}
              </div>

              {/* Full Description */}
              <p className="text-xs sm:text-sm text-[#5C4A42] dark:text-[#C0B1A5] leading-relaxed">
                {product.fullDesc}
              </p>

              {/* Origin & Ingredients */}
              <div className="p-3 rounded-xl bg-black/5 dark:bg-white/5 space-y-1.5 text-xs">
                <p><strong>Origin:</strong> {product.origin}</p>
                <p><strong>Ingredients:</strong> {product.ingredients}</p>
              </div>

              {/* Best For Dishes */}
              <div>
                <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider block mb-2">
                  Best Suited For:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {product.bestFor.map((dish) => (
                    <span
                      key={dish}
                      className="px-2.5 py-1 rounded-lg bg-[#8B0000]/10 dark:bg-[#8B0000]/30 text-[#8B0000] dark:text-[#D4AF37] text-xs font-semibold border border-[#D4AF37]/20"
                    >
                      ✨ {dish}
                    </span>
                  ))}
                </div>
              </div>

              {/* Weight Selector */}
              <div>
                <label className="text-xs font-bold text-[#1F1511] dark:text-[#FAF5EF] uppercase block mb-2">
                  Choose Pack Size:
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {product.weights.map((w, idx) => (
                    <button
                      key={w.weight}
                      onClick={() => setSelectedWeightIndex(idx)}
                      className={`py-2 rounded-xl border text-xs font-bold transition-all ${
                        selectedWeightIndex === idx
                          ? 'bg-[#8B0000] text-white border-[#D4AF37] shadow-md'
                          : 'bg-black/5 dark:bg-white/5 border-transparent text-[#1F1511] dark:text-[#C0B1A5] hover:border-[#D4AF37]/50'
                      }`}
                    >
                      <span className="block">{w.weight}</span>
                      <span className="text-[10px] opacity-80">₹{w.price}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity Counter */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-[#1F1511] dark:text-[#FAF5EF]">Quantity:</span>
                <div className="flex items-center gap-3 bg-black/5 dark:bg-white/5 rounded-xl p-1 border border-[#E6DFD5] dark:border-[#38241B]">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 rounded-lg bg-[#8B0000] text-white font-bold flex items-center justify-center hover:bg-[#660000]"
                  >
                    -
                  </button>
                  <span className="text-sm font-bold w-6 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 rounded-lg bg-[#8B0000] text-white font-bold flex items-center justify-center hover:bg-[#660000]"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Total Price & Primary Actions */}
            <div className="pt-4 border-t border-[#E6DFD5] dark:border-[#38241B] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#5C4A42] dark:text-[#C0B1A5] font-semibold">Total Price:</span>
                <span className="text-2xl font-extrabold font-serif-luxury text-[#1F1511] dark:text-[#FAF5EF]">
                  ₹{totalPrice}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handleAddCart}
                  className={`py-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                    added
                      ? 'bg-emerald-600 text-white border-emerald-500'
                      : 'border-[#D4AF37] text-[#1F1511] dark:text-[#FAF5EF] hover:bg-[#D4AF37]/10'
                  }`}
                >
                  {added ? <Check className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />}
                  <span>{added ? 'Added to Basket!' : 'Add to Basket'}</span>
                </button>

                <button
                  onClick={handleWhatsAppOrder}
                  className="py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2 transition-all hover:scale-105"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Order on WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
