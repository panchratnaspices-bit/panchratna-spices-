import React, { useState, useEffect } from 'react';
import { PageType } from '../types';
import { Sun, Moon, ShoppingBag, Menu, X, Phone, Flame, Search } from 'lucide-react';

interface NavbarProps {
  activePage: PageType;
  setActivePage: (page: PageType) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  cartCount: number;
  openCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  darkMode,
  setDarkMode,
  cartCount,
  openCart,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: PageType; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'products', label: 'Our Spices' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (page: PageType) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'glass-panel shadow-xl py-3 border-b border-[#D4AF37]/30'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
            id="brand-logo-btn"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-gradient-to-br from-[#8B0000] via-[#A00000] to-[#500000] border-2 border-[#D4AF37] flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
              <Flame className="w-6 h-6 text-[#D4AF37] animate-pulse" />
            </div>
            <div>
              <span className="block text-lg sm:text-2xl font-bold font-serif-luxury tracking-wider text-[#1F1511] dark:text-[#FAF5EF]">
                PANCHRATNA
              </span>
              <span className="block text-[10px] sm:text-xs font-semibold tracking-[0.25em] text-[#D4AF37] uppercase">
                SPICES • 100% PURE
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                id={`nav-link-${item.id}`}
                className={`relative py-1 text-sm font-semibold tracking-wide transition-colors ${
                  activePage === item.id
                    ? 'text-[#8B0000] dark:text-[#D4AF37]'
                    : 'text-[#5C4A42] dark:text-[#C0B1A5] hover:text-[#8B0000] dark:hover:text-[#D4AF37]'
                }`}
              >
                {item.label}
                {activePage === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#8B0000] via-[#D4AF37] to-[#8B0000] rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Controls & Quick CTA */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Dark / Light Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 text-[#1F1511] dark:text-[#FAF5EF] transition-colors"
              title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              id="theme-toggle-btn"
            >
              {darkMode ? <Sun className="w-5 h-5 text-[#D4AF37]" /> : <Moon className="w-5 h-5 text-[#8B0000]" />}
            </button>

            {/* WhatsApp / Inquiry Basket Button */}
            <button
              onClick={openCart}
              className="relative p-2 sm:px-4 sm:py-2 rounded-full bg-gradient-to-r from-[#8B0000] to-[#660000] text-[#FAF5EF] border border-[#D4AF37]/50 hover:border-[#D4AF37] shadow-md flex items-center gap-2 text-xs sm:text-sm font-semibold transition-all hover:scale-105"
              id="cart-btn"
            >
              <ShoppingBag className="w-4 h-4 text-[#D4AF37]" />
              <span className="hidden sm:inline">Order Basket</span>
              {cartCount > 0 && (
                <span className="bg-[#D4AF37] text-[#120A07] text-[11px] font-bold px-1.5 py-0.5 rounded-full">
                  {cartCount}
                </span>
              )}
            </button>

            {/* WhatsApp Call Direct CTA */}
            <a
              href="https://wa.me/919823045678?text=Hello%20Panchratna%20Spices!%20I%20would%20like%20to%20know%20more%20about%20your%20spices."
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#D4AF37] text-xs font-bold text-[#D4AF37] hover:bg-[#D4AF37]/10 transition-colors"
              id="quick-whatsapp-nav-btn"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>+91 98230 45678</span>
            </a>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#1F1511] dark:text-[#FAF5EF] focus:outline-none"
              id="mobile-menu-btn"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-panel border-b border-[#D4AF37]/30 px-4 pt-4 pb-6 mt-3 space-y-3 animate-fadeIn">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`block w-full text-left px-4 py-3 rounded-lg text-base font-semibold transition-colors ${
                activePage === item.id
                  ? 'bg-[#8B0000] text-[#FAF5EF]'
                  : 'text-[#1F1511] dark:text-[#FAF5EF] hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-gray-200 dark:border-gray-800 flex justify-between items-center px-4">
            <span className="text-xs text-[#5C4A42] dark:text-[#C0B1A5]">Direct Order Hotline</span>
            <span className="text-xs font-bold text-[#D4AF37]">+91 98230 45678</span>
          </div>
        </div>
      )}
    </header>
  );
};
